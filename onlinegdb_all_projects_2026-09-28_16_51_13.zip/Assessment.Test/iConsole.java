public interface iConsoles 
{
    String getConsoleSale();
    String getStore();
    int. getTotalSales();
}