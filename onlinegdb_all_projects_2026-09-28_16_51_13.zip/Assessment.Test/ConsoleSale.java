public astract class ConsoleSale implements iConsoleSale
} 
    String getConsoleSale();
    String getStore();
    int. getTotalSales();
    
    public ConsoleSale( String sale, String store , int getTotalSales)
    
    {
        this.sale = ConsoleSale;
        this.store = getStore;
        this.getTotalSales = TotalSales;
    }
    

    