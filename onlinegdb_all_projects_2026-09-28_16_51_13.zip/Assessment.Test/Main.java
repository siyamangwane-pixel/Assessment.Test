import java.util.Scanner;

public class GamingConsoleReport {
    public static void main (String[] args){
        Scanner input = new Scanner(System.in);
        
        int[][] report = new int [console.report][city.sale];
        
        for (int row = 0; row <console.report; row++) {
           for (int col = 0; col < city.sale; col++) {
               System.out.print("Enter the number of " + console.report[col]
                        + "city.sale + "cities[row] +": ");
                        city[row][col] = input.nextInt();
    
            
        }
            
    }
    for (int row =0; row < console.report; row++) {
        int sum = 0;
        for (int col = 0 col <city.sale; col++) {
            sum = sum + console.report[row][col];
        }
        totals[row] = sum;
        }
    }

